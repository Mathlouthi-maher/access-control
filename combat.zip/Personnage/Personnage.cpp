#include "persoo.h"

persoo::persoo()
{
    //ctor
}

persoo::~persoo()
{
    //dtor
}
