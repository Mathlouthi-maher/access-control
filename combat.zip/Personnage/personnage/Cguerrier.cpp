/**************************Biblioth�ques**********************/

#include "Cguerrier.h"
#include "Cpersonnage.h"

using namespace std; //Espace de nom standard

/**************************Constructeurs**********************/
Cguerrier::Cguerrier() : Cpersonnage(){
        m_lvl =0;
}

Cguerrier::Cguerrier(Cpersonnage& p) : Cpersonnage(p) { //Un guerrier est un personnage
    m_lvl =1;
}

Cguerrier::~Cguerrier(){


}


void Cguerrier::affiche(int i){ //Affichage du guerrier
    Cpersonnage::affiche(i);
    color (8,15);
    gotoligcol (20,i );cout<<"Niveau : "<<m_lvl;

}
