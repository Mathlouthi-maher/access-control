/**************************Biblioth�que**********************/

#include "Cpersonnage.h"

using namespace std; //Espace de nom standard

/**************************Constructeurs**********************/

//Constructeur de classe par d�faut
Cpersonnage::Cpersonnage(string s,string nomArme, int degats_arme) :  m_nom(s), m_arme(nomArme,degats_arme) {
    m_force = 10 ;
	m_intelligence = 100;
	m_defence = alea(1000);
	m_critique = alea(50);
	m_vie =10000 + m_defence;
	m_ki = 100 ;
}

//Constructeur  de classe par copie
Cpersonnage::Cpersonnage(Cpersonnage& c){
    m_force         = c.m_force ;
	m_intelligence  = c.m_intelligence;
	m_defence       = c.m_defence;
	m_critique      = c.m_critique;
	m_vie           = c.m_vie;
	m_ki            = c.m_ki ;
    m_nom           = c.m_nom;
    m_arme          = c.m_arme;
}

/**************************Destructeur**********************/

Cpersonnage::~Cpersonnage(){} //Destructeur de classe

/**************************M�thodes**********************/

//M�thode g�rant l'affichage des personnages
void Cpersonnage::affiche(int i){ //i correspond au d�callage en colonne

    gotoligcol (14,i );
    cout << "   "<< m_nom ;

    gotoligcol (15,i  );
    cout << "Force :";
    if (m_force<100) {color(12,15);cout << m_force;}  //Force d'abord rouge, puis dor�e
    else {color(14,15);cout << m_force;}
    color(0,15);

    gotoligcol (16,i );
    cout << "Intelligence :"; //Intelligence verte puis blanche quand vide
    if (m_intelligence>=50) {color(10,15);cout << m_intelligence << "    ";}
    else {color(0,15); cout << m_intelligence << "    ";}
    color(0,15);

    gotoligcol (17,i );
    cout << "Vie :"; //Vie verte, puis jaune, puis rouge, puis blanche quand vide
    if (m_vie>5000){color(10,15);cout << m_vie<< "   ";}
    if (m_vie<5000 && m_vie>2000){color(14,15); cout << m_vie<< "    ";}
    if (m_vie<2000 && m_vie != 0){color(12,15); cout << m_vie << "    ";}
    if (m_vie==0){color(0,15); cout << m_vie << "    ";}
    color(0,15);

    gotoligcol (18,i );
    cout << "Ki :";  //Ki vert, puis blanc quand vide
    if (m_ki>50){color(10,15);cout << m_ki<< "   ";}
    if (m_ki<50){color(0,15);cout << m_ki<< "   ";}
    color(0,15);

    gotoligcol (19,i );
    m_arme.afficher(1);
    }

//M�thode g�rant les barres de vie et de ki des personnages
void Cpersonnage::jauge(string a,int b){ //D�pend de deux param�tres (type et position)
    int barre_vie = m_vie/333;           //Calcul des unit�s de jauge
    int barre_ki  = m_ki/10;

    if (a == "vie" && b==0)
    {
        gotoligcol(22,0);
        color (0,15);
        cout << "Vie :";
         for(int i=6;i<43;i++)
        {
            gotoligcol(22,i);//efface vie
            color(7,0);cout<<" ";color(7,0);
        }
        if (m_vie > 5000)
        {
           for (int i=6;i<barre_vie+6;i++)
            {
                color(0,10);
                gotoligcol(22,i);
                cout <<"|";
                color(7,0);
            }
        }
        if (m_vie<5000 && m_vie>2000)
        {
           for (int i=6;i<barre_vie+6;i++)
            {
                color(0,14);
                gotoligcol(22,i);
                cout <<"|";
                color(7,0);
            }
        }
        if (m_vie<2000)
        {
           for (int i=6;i<barre_vie+6;i++)
            {
                color(0,12);
                gotoligcol(22,i);
                cout <<"|";
                color(7,0);
            }
        }
    }

if (a == "vie" && b==1)
    {
        gotoligcol(22,95);
        color (0,15);
        cout << "Vie :";
         for(int i=101;i<139;i++)
        {
            gotoligcol(22,i);//efface vie
            color(7,0);cout<<" ";color(7,0);
        }
        if (m_vie > 5000)
        {
           for (int i=101;i<barre_vie+101;i++)
            {
                color(0,10);
                gotoligcol(22,i);
                cout <<"|";
                color(7,0);
            }
        }
        if (m_vie<5000 && m_vie>2000)
        {
           for (int i=101;i<barre_vie+101;i++)
            {
                color(0,14);
                gotoligcol(22,i);
                cout <<"|";
                color(7,0);
            }
        }
        if (m_vie<2000)
        {
           for (int i=101;i<barre_vie+101;i++)
            {
                color(0,12);
                gotoligcol(22,i);
                cout <<"|";
                color(7,0);
            }
        }
    }
    if (a == "ki" && b==0 )
    {
        gotoligcol(23,0);
        color (0,15);
        cout << "Ki  :";
        for(int i=6;i<26;i++)
                {
                    gotoligcol(23,i);//efface ki
                    color(7,0);cout<<" ";color(7,0);
                }
           for (int i=6;i<barre_ki+6;i++)
            {
                color(0,14);
                gotoligcol(23,i);
                cout <<"|";
                color(7,0);
            }
    }

    if (a == "ki" && b==1 )
    {
        gotoligcol(23,95);
        color (0,15);
        cout << "Ki  :";
        for(int i=101;i<121;i++)
                {
                    gotoligcol(23,i);//efface ki
                    color(7,0);cout<<" ";color(7,0);
                }
           for (int i=101;i<barre_ki+101;i++)
            {
                color(0,14);
                gotoligcol(23,i);
                cout <<"|";
                color(7,0);
            }
    }
}

//M�thode d'attaque
int Cpersonnage::coup_de_poing(Cpersonnage* & c){
    int degats(m_force*50 + m_critique);
    c->m_vie = c->m_vie - degats ;
    if (c->m_vie < 0) c->m_vie = 0;}

//M�thode d'attaque
int Cpersonnage::coup_de_pied(Cpersonnage* & c){
    int degats(m_force*150 + m_critique);
    c->m_vie = c->m_vie - degats;
    if (c->m_vie < 0) c->m_vie = 0;
}

//M�thode d'attaque utilisant la classe arme
int Cpersonnage::coup_arme(Cpersonnage* & c){
    int degats(m_arme.donnerDegats());
    c->m_vie = c->m_vie - degats;
    if (c->m_vie < 0) c->m_vie = 0;
}

//M�thode passant le personnage en mode "Rage" (augmente force mais diminue vie )
int Cpersonnage::rage(){
    m_vie=m_vie - 0.30*m_vie;
    m_force = m_force + 0.4*m_force;
}

//M�thode qui soigne le personnage
int Cpersonnage::regenere(){
    if (m_ki > 0 ) {
    m_ki=m_ki - 50;
    m_vie = m_vie + 500;}
    if (m_ki < 0) {m_ki = 0;}
    return (m_ki);
    }

//M�thode qui recharge le ki du personnage (diminue intelligence)
int Cpersonnage::recharge_ki(){

    int i;
    if (m_intelligence > 0 ) { m_ki=m_ki + 50;
    i++;
    m_intelligence=m_intelligence - 50;
    }
    if (m_intelligence < 0) {m_intelligence = 0;}
    return (m_intelligence);
    }

//M�thode d'attaque (puissant mais diminue le ki)
int Cpersonnage::boule_d_energie(Cpersonnage* & c){
    int degats(m_force*300 + m_critique);
    if (m_ki >= 50 )
    {
        m_ki=m_ki - 50;
        c->m_vie = c->m_vie - degats;
    }
    if (m_ki < 0)
    {
        m_ki = 0;
    }
    if (c->m_vie < 0)
    {
        c->m_vie = 0;
    }
    return(m_ki);

}

//M�thode qui renvoie si le personnage est en vie ou non
bool Cpersonnage::enVie(void){
    if(m_vie<=0){
    return(0);}
    if(m_vie>0){
    return(1);}
    }

//M�thode qui permet au personnage de changer d'arme
void Cpersonnage::changerArme(string nomNouvelleArme, int degatsNouvelleArme ){
    m_arme.changer(nomNouvelleArme,degatsNouvelleArme);
}

//Affiche des infos dans le carr� central, trois types d'affichage suivant l'info � �crire
void Cpersonnage::historique(string s ,Cpersonnage* & c, int a){
    if (a == 1){
    cout << m_nom << s << c->m_nom<< endl;}
    if (a == 0){
    cout << m_nom << s << endl;
    }
    if (a==2){
    cout << m_nom <<" met un coup de "; m_arme.afficher(0); cout <<" � "<< c->m_nom;
    }
}


/**************************Fonctions**********************/

//Fonction g�rant les nombres al�atoires
int alea(int n){
	static int first(1);
	if(first == 1){
	    srand(time(NULL));
        first = 0 ;}
	return rand()%n+1;}

//Fonction g�rant la position du texte
void gotoligcol( int lig, int col ){
    COORD mycoord;
    mycoord.X = col;
    mycoord.Y = lig;
    SetConsoleCursorPosition( GetStdHandle( STD_OUTPUT_HANDLE ), mycoord );}

//Fonction g�rant la couleur du texte
void color(int t,int f){
         HANDLE H=GetStdHandle(STD_OUTPUT_HANDLE);
		 SetConsoleTextAttribute(H,f*16+t);
}

//Fonction affichant les r�gles et qui d�marre le jeu
void initialisation_jeu(void){
    int touche;
    color (0,15);
    gotoligcol(0,0);
    cout << "Pressez la touche entr�e pour lancer le jeu :";
    gotoligcol(0,47);
    touche = getch();

    gotoligcol(2,0);
    cout << "A : Coup de poing ";
    gotoligcol(3,0);
    cout << "Z : Coup de pied ";
    gotoligcol(4,0);
    cout << "E : Boule d'�nergie ";
    gotoligcol(5,0);
    cout << "Q : Recharger ki ";
    gotoligcol(6,0);
    cout << "S : Soin ";
    gotoligcol(7,0);
    cout << "D : Rage ";
    gotoligcol(8,0);
    cout << "W : Coup d'arme ";
    gotoligcol(9,0);
    cout << "X : Changer d'arme ";

    gotoligcol(2,35);
    cout << "I : Coup de poing ";
    gotoligcol(3,35);
    cout << "O : Coup de pied ";
    gotoligcol(4,35);
    cout << "P : Boule d'�nergie ";
    gotoligcol(5,35);
    cout << "K : Recharger ki ";
    gotoligcol(6,35);
    cout << "L : Soin ";
    gotoligcol(7,35);
    cout << "M : Rage ";
    gotoligcol(8,35);
    cout << "B : Coup d'arme ";
    gotoligcol(9,35);
    cout << "N : Changer d'arme ";

    for(int i=0;i<60;i++)
    {
     gotoligcol(10,i);
     cout <<"_";
    }
    for(int i=0;i<11;i++)
    {
     gotoligcol(i,60);
     cout <<"|";
    }


}

//Fonction qui permet d'obtenir getch() => alternative � cin
int MyGetch(){
#ifdef _WIN32
    return getch();
#endif
// trouver alternative hors Windows.
}

