/**************************Biblioth�ques**********************/

#ifndef CCOMBAT_H
#define CCOMBAT_H
#include <iostream>
#include <iomanip>
#include <string>
#include "Cpersonnage.h"
#include "Cguerrier.h"

/**************************Classe Ccombat********************/

class Ccombat{
    public:
        Ccombat(void);
        ~Ccombat();
        void combat(Cpersonnage*,Cpersonnage*);

    protected:

        int m_compteur;


    private:
};

#endif // CCOMBAT_H
