/**************************Biblioth�ques**********************/

#include <iostream>
#include <iomanip>
#include <string>
#include <ctime>
#include <cstdlib>
#ifdef _WIN32
	#include <Windows.h>
	#include <conio.h>
#endif
#ifndef CPERSONNAGE_H
#define CPERSONNAGE_H
#include "C_arme.h"

/**************************Prototypes************************/

int alea(int);
void gotoligcol (int lig, int col);
void color(int t,int f);
int MyGetch();
void initialisation_jeu(void);

/**************************Classe Cpersonnage****************/

class Cpersonnage{

    public:
        Cpersonnage(std::string="",std::string="",int=0);    //Constructeur par d�faut
        Cpersonnage(Cpersonnage& c);                         //Constructeur par copie
        virtual ~Cpersonnage();                              //Destructeur virtuel

    public:                                                  //M�thodes du personnages
        void affiche(int);
        bool enVie(void);
        int  coup_de_poing(Cpersonnage* & c);
        int  coup_de_pied(Cpersonnage* & c);
        int  rage();
        int  boule_d_energie(Cpersonnage* & c);
        int  coup_arme(Cpersonnage* & c);
        void changerArme(std::string , int );
        int  regenere();
        int  recharge_ki();
        void historique(std ::string,Cpersonnage* & c,int);
        void jauge(std::string, int);

    protected:                                               //Variables du personnage
        int m_vie;
        std::string m_nom;
        int m_force;
        int m_defence;
        int m_intelligence;
        int m_ki;
        int m_critique;
        C_arme m_arme;

    private:

};

#endif // CPERSONNAGE_H
