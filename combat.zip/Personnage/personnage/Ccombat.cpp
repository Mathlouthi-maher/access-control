/**************************Biblioth�que**********************/

#include "Ccombat.h"

using namespace std;

/**************************Constructeurs**********************/

Ccombat::Ccombat(void){ //Initialisation du combat
m_compteur = 1;
gotoligcol(12,45);
cout <<"D�but du combat Goku VS Vegeta"<<endl;
gotoligcol(14,57);
cout << "Combat " << m_compteur;
}

/**************************Destructeur**********************/

Ccombat::~Ccombat(){
}

/**************************M�thode**********************/

void Ccombat::combat(Cpersonnage* p1,Cpersonnage* p2){
    int touche_j;
    int rang_1 =0;
    int rang_2 =0;


while(/*p1->enVie() && p2 ->enVie()*/1){

    //Affichage des personnages
    p1->affiche(1);
    p2->affiche(95);

    //Jauge
    p1->jauge("vie",0);
    p2->jauge("vie",1);
    p1->jauge("ki",0);
    p2->jauge("ki",1);

    //Carr� central
    for(int i=40;i<82;i++)
    {
     color (0,15);
     gotoligcol(18,i);
     cout <<"_";
    }
     for(int i=40;i<82;i++)
    {
     color (0,15);
     gotoligcol(15,i);
     cout <<"_";
    }
    for(int i=16;i<19;i++)
    {
     color (0,15);
     gotoligcol(i,39);
     cout <<"|";
    }
    for(int i=16;i<19;i++)
    {
     color (0,15);
     gotoligcol(i,82);
     cout <<"|";
    }

    touche_j=getch(); //On r�cup�re une touche

    //Choix de l'action � faire suivant la touche
    if(p1->enVie()==1 && p2->enVie()==1 ){
    switch (touche_j){
    case 'a':
    p1->coup_de_poing(p2);
    if (p2->enVie()==1){
    gotoligcol(17,44);
    p1->historique(" met un coup de poing � ",p2,1);
    Sleep(500);
    gotoligcol(17,44);
    cout << "                                       ";
    }
    break;
    case 'z':
    Sleep(500);
    p1->coup_de_pied(p2);
    if (p2->enVie()==1){
    gotoligcol(17,44);
    p1->historique(" met un coup de pied � ",p2,1);
    Sleep(500);
    gotoligcol(17,44);
    cout << "                                       ";
    }
    break;
    case 'e':
    if (p2->enVie()==1 && ((p1->boule_d_energie(p2))>=50) )
    {
    gotoligcol(17,47);
    p1->historique(" lance une salve � ",p2,1);
    Sleep(500);
    gotoligcol(17,47);
    cout << "                                       ";
    }
    break;
    case 'q':
    if (p1->enVie()==1 && p2->enVie()==1 &&  ((p1->recharge_ki())>= 50) ){
    gotoligcol(17,49);
    p1->historique(" recharge son ki",p2,0);
    Sleep(500);
    gotoligcol(17,49);
    cout << "                                       ";
    }
    break;
    case 's':
    if (p1->enVie()==1 && p2->enVie()==1 && ((p1->regenere())>= 50) ){
    gotoligcol(17,52);
    p1->historique(" se regenere ",p2, 0);
    Sleep(500);
    gotoligcol(17,52);
    cout << "                                       ";
    }
    break;
    case 'd':
    if (p2->enVie()==1){
        p1->rage();
        gotoligcol(17,52);
        p1->historique(" rentre en rage ",p2, 0);
        Sleep(500);
    gotoligcol(17,52);
    cout << "                                       ";}
    break;
    case 'w' :
    if (p2->enVie()==1){
    p1->coup_arme(p2);
    gotoligcol(17,42);
    p1->historique("",p2, 2);
    Sleep(500);
    gotoligcol(17,42);
    cout << "                                       ";
    }
    break;
    case 'x' :
    rang_1++;
    if (p1->enVie()==1 && p2->enVie()==1 ){
       if (rang_1 ==1 || rang_1 ==3 || rang_1 ==5 || rang_1 ==7){
        p1->changerArme("shuriken",500);}
        if (rang_1 ==2 || rang_1 == 4 || rang_1 ==6 || rang_1 ==8 ){
        p1->changerArme("baton",300);}
        }
    break;
    case 'i':
    p2->coup_de_poing(p1);
    if (p1->enVie()==1){
    gotoligcol(17,44);
    p2->historique(" met un coup de poing � ",p1,1);
    Sleep(500);
    gotoligcol(17,44);
    cout << "                                       ";}
    break;
    case 'o':
    Sleep(500);
    p2->coup_de_pied(p1);
    if (p1->enVie()==1){
    gotoligcol(17,44);
    p2->historique(" met un coup de pied � ",p1,1);
    Sleep(500);
    gotoligcol(17,44);
    cout << "                                       ";}
    break;
    case 'p':
    if (p1->enVie()==1 && (p2->boule_d_energie(p1))>=50){
    gotoligcol(17,47);
    p2->historique(" lance une salve � ",p1,1);
    Sleep(500);
    gotoligcol(17,47);
    cout << "                                       ";}
    break;
    case 'k':
    if (p2->enVie()==1 && p1->enVie()==1 && ((p2->recharge_ki())>= 50) ){
    gotoligcol(17,49);
    p2->historique(" recharge son ki",p1,0);
    Sleep(500);
    gotoligcol(17,49);
    cout << "                                       ";}
    break;
    case 'l':
    if (p2->enVie()==1 && p1->enVie()==1 &&((p2->regenere())>= 50) ){
    gotoligcol(17,52);
    p2->historique(" se regenere ",p1,0);
    Sleep(500);
    gotoligcol(17,52);
    cout << "                                       ";}
    break;
    case 'm':
    if (p2->enVie()==1){
    p2->rage();
    gotoligcol(17,52);
    p2->historique(" rentre en rage ",p1, 0);
    Sleep(500);
    gotoligcol(17,52);
    cout << "                                       ";}
    break;
    case 'b' :
    if (p1->enVie()==1){
    p2->coup_arme(p1);
    gotoligcol(17,42);
    p2->historique("",p1, 2);
    Sleep(500);
    gotoligcol(17,42);
    cout << "                                       ";
    }
    break;
    case 'n' :
    rang_2++;
    if (p1->enVie()==1 && p2->enVie()==1 ){
        if (rang_2 ==1 || rang_2 ==3 || rang_2 ==5 || rang_2 ==7){
        p2->changerArme("sabre",500);}
        if (rang_2 ==2 || rang_2 == 4 || rang_2 ==6 || rang_2 ==8 ){
        p2->changerArme("nunchaku",300);}
        }
    break;}}

    if (p1->enVie()==0) //Si Goku est mort, on l'affiche
    {
        color (12,15);
        gotoligcol(27,0);
        cout << "Goku est mort";
        color (0,15);
    }

    if (p2->enVie()==0) //Si Vegeta est mort, on l'affiche
    {
        color (12,15);
        gotoligcol(28,0);
        cout << "Vegeta est mort";
        color (0,15);
    }

}
}
