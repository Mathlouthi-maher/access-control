/**************************Biblioth�ques**********************/

#ifndef CGUERRIER_H
#define CGUERRIER_H
#include "Cpersonnage.h"

/**************************Classe Cguerrier********************/

class Cguerrier : public Cpersonnage  //Guerrier h�rite de personnage
{
    public:
        Cguerrier();
        Cguerrier(Cpersonnage&);
        virtual ~Cguerrier();
        void affiche(int);
    protected:
        int m_lvl;
    private:

};

#endif // CGUERRIER_H
