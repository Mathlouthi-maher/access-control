/**************************************************************
Projet de POO
Guillaume AUBERT GEII2
Ann�e 2017/2018

Remarque : - Ajouter d�fence
           - Augmenter r�alisme
           - Ajouter son
           - G�rer les combats ( compteur + relancer )
           - G�rer les �volutions
           - G�rer les 500 ms
           - G�rer changement d'arme

**************************************************************/

#include <locale>
#include <string>
#include "Cpersonnage.h"
#include "Ccombat.h"
#include "Cguerrier.h"

/**************************************************************/

using namespace std;

int main()
{
    color (0,15);                                                   //Passe la console en fond blanc
    setlocale (LC_ALL,"");                                          //Gestion des accents
    initialisation_jeu();                                           //Affichage des r�gles du jeu

    Ccombat C;                                                      //Cr�ation d'un combat
    Cpersonnage p1("Goku","baton",350),p2("Vegeta","nunchaku",300); //Cr�ation de deux personnages
    Cguerrier g1(p1),g2(p2);                                        //Cr�ation de deux guerriers
    C.combat(&g1,&g2);                                              //Lance un combat entre deux guerriers

    return 0;
}

/**************************************************************/
