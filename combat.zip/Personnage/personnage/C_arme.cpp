/**************************Biblioth�que**********************/

#include "C_arme.h"

using namespace std; //Espace de nom standard

/**************************Constructeurs**********************/

C_arme::C_arme() {
}

C_arme::C_arme(string nom, int degats) : m_nom(nom), m_degats(degats){
}

C_arme::C_arme(C_arme& a){
    m_degats = a.m_degats;
    m_nom    = a.m_nom;
}

/**************************Destructeur**********************/

C_arme::~C_arme(){
}

/**************************M�thodes**********************/

//M�thode permettant de changer d'arme
void C_arme::changer(string nom, int degats){

        m_nom = nom;
        m_degats = degats;
}

//M�thode affichant l'arme
void C_arme::afficher(int a){
    if (a==1){
    cout << "Arme : " << m_nom << " (D�g�ts : " << m_degats << ")   " << endl;}
    if (a==0){
    cout <<  m_nom; }
}

//M�thode qui donne les d�gats de l'arme
int C_arme::donnerDegats() const{
    return m_degats;
}
