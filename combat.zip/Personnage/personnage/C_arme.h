/**************************Biblioth�que**********************/

#ifndef C_ARME_H
#define C_ARME_H
#include <iostream>
#include <iomanip>
#include <string>

/**************************Classe C_arme********************/

class C_arme{
    public:
        C_arme();
        C_arme(std::string nom, int degats);
        C_arme(C_arme& );
        ~C_arme();

    public :

        void changer(std::string nom, int degats);
        void afficher(int);
        int donnerDegats() const;
    protected:
        std::string m_nom;
        int m_degats;

    private:
};

#endif // C_ARME_H
