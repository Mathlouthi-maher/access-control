#ifndef PERSOO_H
#define PERSOO_H


class persoo
{
    public:
        persoo();
        ~persoo();

    protected:

    private:
};

#endif // PERSOO_H
