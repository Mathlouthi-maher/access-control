#include "Ccombat.h"

Ccombat::Ccombat()
{
    //ctor
}

Ccombat::~Ccombat()
{
    //dtor
}
