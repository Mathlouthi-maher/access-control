#include "Cperso.h"                                                                             //on d�fini la biblioth�que Cperso.h


using namespace std;                                                                            //on d�fini la biblioth�que standard

Cperso::Cperso(string nom) : m_nom(nom)  {                                                    //on d�fini le constructeur Cperso

    m_forc 	  = 70     + alea   (10);
	m_inte 	  = 200    - alea   (20);
	m_cons 	  = 40     + alea   (20);
	m_HP	  = 300    + m_cons;
    m_HPMax	  = m_HP;
	m_mana	  = m_inte + alea(20);
	m_manaMax = m_mana;
}
Cperso::~Cperso()  {                                                                             //on d�fini le destructeur Cperso

}

void    Cperso::affiche(int a){                                                                     //on d�fini la m�thode affiche pour un entier

        gotoligcol(6, a*MIDDLE);        cout<<m_nom <<endl;
        gotoligcol(7, a*MIDDLE);        cout<<""<<endl;
        gotoligcol(8, a*MIDDLE);        cout<<"Points de vie  = "<<m_HP<<" / "<<m_HPMax<<"        "<<endl;
        gotoligcol(9, a*MIDDLE);        cout<<"Attaque        = "<<m_forc<<endl;
        gotoligcol(10, a*MIDDLE);        cout<<"D�fense        = "<<m_cons<<endl;
        gotoligcol(11,a*MIDDLE);        cout<<"Mana           = "<<m_mana<<" / "<<m_manaMax<<"    "<<endl;
        gotoligcol(12,a*MIDDLE);        cout<<"Intelligence   = "<<m_inte<<endl;
}

int     Cperso::attaquer(Cperso & c)   {                                                             //on d�fini la m�thode attaquer de la copie de Cperso

    int degats ( alea(50) + m_forc );

    c.m_HP = c.m_HP - degats;

    if (c.m_HP <= 0)    {
        c.m_HP = 0;
        gotoligcol(20,0);        cout<<c.
        m_nom<<" est mort"<<endl;
        cout<<endl;
    }
    return degats;
}
int     Cperso::soigner(void)    {                                                               //on d�fini la m�thode soigner de la copie de Cperso

    int pointsDeVie (m_manaMax - 100);

    if( m_mana <= 0 ){

    m_mana = 0;
    } else if (m_mana > 50) {

        m_mana = m_mana - 50;
        m_HP   = m_HP   + pointsDeVie;
        }

    if (m_mana <= 50 ){

    pointsDeVie = 0;
    }

    if (m_HPMax <= m_HP ){

    m_HP = m_HPMax;
    }

    return pointsDeVie;
}


int     Cperso::isAlive(void)   {
    return ( m_HP > 0 );
    }                                    //on d�fini la m�thode is Alive

string  Cperso::getNom(void)    {
    return m_nom;
    }


/**************************Fonctions **************************/

int alea(int n)                    {                                                         //on utilise l'entier alea qui a pour param�tre l'entier n
	static int first(1);                                                                        //on d�fini un entier statique nomm� first qui a pour param�tre 1

	if(first == 1)                                                                              //si first vaut 1
	{ 	srand(time(NULL));                                                                      //on utilise la fonction qui permet de prendre un chiffre bas� sur le tps de l'ordi
        first = 0 ;                                                                             //first vaut 0
    }

	return rand()%n+1;                                                                          //renvoi random
}
void gotoligcol( int lig, int col ){
    COORD mycoord;
    mycoord.X = col;
    mycoord.Y = lig;
    SetConsoleCursorPosition( GetStdHandle( STD_OUTPUT_HANDLE ), mycoord );
}
