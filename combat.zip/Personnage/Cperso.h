#ifndef CPERSO_H                                                                            //si la biblioth�que Cperso n'existe pas
#define CPERSO_H                                                                            //on d�fini la biblioth�qye Cperso
#include <iostream>                                                                         //on d�fini la biblioth�que iostream
#include <iomanip>                                                                          //on d�fini la biblioth�que iomanip qui permet de manipuler les E/S
#include <string>                                                                           //on d�fini la biblioth�que qui permet d'utiliser des chaines de caract�res
#include <ctime>                                                                            //on d�fini la biblioth�que qui nous permet d'utiliser le temps de l'ordinateur pour la fonction random
#include <cstdlib>                                                                          //on d�fini la biblioth�que standard

#ifdef _WIN32
#include <windows.h>                                                                    //pour gotoligcol et sleep pour le d�lai
#include <conio.h>
#endif

#define MIDDLE 35

int alea(int);                                                                              //on d�fini un entier nomm� alea qui a pour param�tre un entier
void gotoligcol( int lig, int col );
class Cperso                                                                                //on d�fini la classe Cperso
{
    public:                                                                                 //d�claration des m�thodes en public

        Cperso(std::string nom);                                                            //on d�clare la m�thode Cperso avec pour param�tre la chaine de caract�re nom
        Cperso(Cperso const & c);                                                           //on d�clare la m�thode qui a pour copie Cperso et qui s'appele c
        ~Cperso();                                                                          //on d�clare le destructeur Cperso

        void affiche(int a);                                                                //on d�fini la m�thode qui affiche l'entier a
        void actualiserVieMana(int pos);
        int attaquer(Cperso & c);                                                           //on d�fini l'entier attaquer avec la copie de Cperso nomm�e c                                                            //on d�fini l'entier soigner avec la copie de Cperso nomm� c
        int soigner (void);                                                                      //on d�fini l'entier soigner qui ne renvoi rien
        int isAlive (void);                                                                      //on d�fini l'entier isAlive qui ne renvoi rien

        std::string getNom(void);


    protected:                                                                              //d�claration des m�thodes en protected

        std::string m_nom;                                                                  //on d�fini la chaine de caract�re nomm�e m_nom
        int m_forc;                                                                         //on d�fini l'entier m_forc
        int m_cons;                                                                         //on d�fini l'entier m_cons
        int m_inte;                                                                         //on d�fini l'entier m_inte
        int m_HP;                                                                           //on d�fini l'entier m_HP
        int m_mana;                                                                         //on d�fini l'entier m_mana
        int m_HPMax;                                                                      //on d�fini l'entier m_HP
        int m_manaMax;
    private:
};

#endif
