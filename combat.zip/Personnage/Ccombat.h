#ifndef CCOMBAT_H
#define CCOMBAT_H


class Ccombat
{
    public:
        Ccombat();
        ~Ccombat();
    protected:
    private:
};

#endif // CCOMBAT_H


/*
for(int i = 0; i<5; i++){
    gotoligcol(i, 15);
    cout<<"-";
}
*/
