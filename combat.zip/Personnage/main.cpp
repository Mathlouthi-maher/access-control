#include "Cperso.h"                                                                     //on ajoute la biblioth�que Cperso.h
#include <locale>

using namespace std;                                                                    //on ajoute la biblioth�que standard

int main()                                                                              //d�but du programme
{
    setlocale (LC_ALL,"");

    string nom_P1, nom_P2;
    Cperso *tperso[2];

    int persoEnCours;

    char a;


    cout<< "Nom du premier  combattant:  ";     gotoligcol(0,29);  cin>> nom_P1; tperso[0] = new Cperso(nom_P1); // d�claration du premier joueur
    cout<< "Nom du deuxi�me combattant:  ";     gotoligcol(1,29);  cin>> nom_P2; tperso[1] = new Cperso(nom_P2); // d�claration du deuxi�me joueur

    gotoligcol(0,83);  cout<<"Historique ";

    for(int i = 0;  i < 5; i++)   { gotoligcol(i, 65);  cout<<"|"; }         // cr�ation du fond pour l'historique des comp�tences ce faire beau et laisible
    for(int i = 0;  i < 5; i++)   { gotoligcol(i, 125); cout<<"|"; }         // ....
    for(int i = 83; i < 95; i++) { gotoligcol(1,i);    cout<<"_"; }         // ...
    for(int i = 66; i < 125; i++) { gotoligcol(4,i);    cout<<"_"; }         // ..


    tperso[0]->affiche(0);                                                  // afficher le premier joueur
    tperso[1]->affiche(1);                                                  // afficher le deuxi�me joueur

    persoEnCours = alea(2) -1;

    do
    {

        gotoligcol(14,0);        cout<<tperso[persoEnCours]->getNom()<<" doit : "<<endl;
        gotoligcol(14,32);       cout<<"      Frapper "<<tperso[!persoEnCours]->getNom()<<" appuyez sur_A";
        gotoligcol(15,32);       cout<<"      Se soigner appuyez sur S";
        gotoligcol(16,0);        cout<<"Choix : ";
        gotoligcol(16,9);        cin>> a;

        if( a == 'A')                         // Condition pour attaquer
        {

            gotoligcol(3,80); cout<<tperso[persoEnCours]->getNom()<<" fait ";
            cout<<tperso[persoEnCours]->attaquer( *tperso[!persoEnCours] )<<" points de d�gats � "<<tperso[!persoEnCours]->getNom();

            Sleep(1000);

            tperso[persoEnCours] -> affiche(persoEnCours);
            tperso[!persoEnCours]-> affiche(!persoEnCours);

         }else if (a == 'S')                 // Condition pour soigner
         {

            gotoligcol(3,80); cout<<tperso[persoEnCours]->getNom()<<" se soigne ";
            cout<<tperso[persoEnCours]->soigner();

            Sleep(1000);

            tperso[persoEnCours] -> affiche(persoEnCours);// On affiche les valeurs du premier joueur en temps r�el
            tperso[!persoEnCours]-> affiche(!persoEnCours);// On affiche les valeurs du deuxi�me joueur en temps r�el
        }

        gotoligcol(14,0);        cout<<"                                          "<<endl;
        gotoligcol(16,9);        cout<<"                                          "<<endl;
        gotoligcol(3,80);        cout<<"                                          "<<endl;

        persoEnCours = ! persoEnCours;

    }
    while ( tperso[persoEnCours] ->isAlive()==1);

    gotoligcol(19,0);        cout<<"                                      "<<endl;

    delete tperso[0];
    delete tperso[1];

    return 0;                                                                           //fin du programme
}
